/*1) Desenvolva um programa que solicite ao usuário digitar dois valores inteiros.
Após a digitação, o computador deverá executar a soma destes números e
mostrar o resultado na tela do computador.*/

#include <stdio.h>

int main()
{
    int valor1;
    int valor2;
    int resultado;
    
    printf("Digite um numero usuario: ");
    scanf("%d", &valor1);
    
    printf("Digite outro numero: ");
    scanf("%d", &valor2);
    
    resultado = valor1 + valor2;
    
    printf("A soma de %d + %d = %d", valor1, valor2,resultado);
}